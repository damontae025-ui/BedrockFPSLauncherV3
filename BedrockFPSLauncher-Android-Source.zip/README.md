# Bedrock FPS Launcher (Android source)

A small unofficial Android companion launcher for Minecraft Bedrock.

## Features
- Minecraft-inspired dark/grass-green home screen
- Launches the installed Minecraft Bedrock app (`com.mojang.minecraftpe`)
- Opens a document picker for `.mcpack` / `.mcaddon` / compatible visual-pack files and hands the selected file to Android's app handler
- In-app CurseForge Bedrock add-ons browser
- Safe FPS optimization guide

## Important limitations
- This is a companion launcher, not a modified Minecraft client.
- It cannot inject mods, change Bedrock's internal graphics settings, or guarantee an FPS increase.
- Add-ons and shader/texture packs must be downloaded separately and must support the user's Bedrock version/device. The app does not bundle a shader pack.
- Android/Minecraft may not accept every file format through the generic file handoff. If needed, open the downloaded pack from the Files app and choose Minecraft.
- CurseForge is displayed as a website inside a WebView; sign-in/download behavior may depend on CurseForge and Android WebView policies.

## Build an APK
Requires Android Studio (recommended) or Android SDK + Gradle, JDK 17+, and internet access for Gradle dependencies.

1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Android Studio will create the APK under `app/build/outputs/apk/debug/`.

Package: `com.example.bedrockfps`
Minimum Android: 6.0 (API 23)
Target SDK: 35

This project is not affiliated with Mojang, Microsoft, Minecraft, or CurseForge.
