package com.example.bedrockfps

import android.app.Activity
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.LinearLayout
import android.widget.TextView

class BrowserActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF14251B.toInt())
        }
        val heading = TextView(this).apply {
            text = "CURSEFORGE  •  BEDROCK ADD-ONS"
            textSize = 17f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(18, 18, 18, 18)
        }
        val web = WebView(this).apply {
            settings.javaScriptEnabled = false
            settings.domStorageEnabled = true
            webViewClient = WebViewClient()
            loadUrl("https://www.curseforge.com/minecraft-bedrock/addons")
        }
        root.addView(heading)
        root.addView(web, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    @Deprecated("Deprecated in Android")
    override fun onBackPressed() {
        finish()
    }
}
