package com.example.bedrockfps

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val green = 0xFF70C34A.toInt()
    private val dark = 0xFF14251B.toInt()
    private val panel = 0xFF203A2A.toInt()
    private val cream = 0xFFF3F4E8.toInt()
    private val prefs by lazy { getSharedPreferences("launcher", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun text(value: String, size: Float, color: Int = cream, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
            setPadding(0, 5, 0, 5)
        }

    private fun button(label: String, action: () -> Unit, primary: Boolean = false): Button =
        Button(this).apply {
            text = label
            isAllCaps = false
            textSize = 15f
            setTextColor(if (primary) 0xFF102014.toInt() else cream)
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(if (primary) green else panel))
            setOnClickListener { action() }
        }

    private fun card(parent: LinearLayout, title: String, body: String, actionLabel: String? = null, action: (() -> Unit)? = null) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 14, 18, 14)
            setBackgroundColor(panel)
        }
        box.addView(text(title, 18f, green, true))
        box.addView(text(body, 14f))
        if (actionLabel != null && action != null) {
            val b = button(actionLabel, action, true)
            val p = LinearLayout.LayoutParams(-1, -2)
            p.topMargin = 10
            box.addView(b, p)
        }
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.setMargins(0, 0, 0, 14)
        parent.addView(box, lp)
    }

    private fun showHome() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(dark)
            setPadding(18, 18, 18, 10)
        }
        root.addView(text("▰  BEDROCK FPS LAUNCHER", 22f, cream, true))
        root.addView(text("ANDROID EDITION  •  COMMUNITY ADD-ON HUB", 11f, green, true))
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 16, 0, 8) }

        card(content, "READY TO PLAY?", "Open your installed Minecraft Bedrock app. This launcher does not replace or modify the official game.", "▶  PLAY MINECRAFT") { launchMinecraft() }
        card(content, "⚡ FPS OPTIMIZER", "Use the in-game Video settings: lower render distance, turn off fancy graphics and reduce particles. These are recommendations; Android apps cannot force Bedrock's internal graphics settings.", "VIEW PERFORMANCE TIPS") { showPerformance() }
        card(content, "▦  ADD-ON MANAGER", "Import compatible .mcpack or .mcaddon files. Minecraft handles the actual import and activation.", "IMPORT ADD-ON") { pickPack() }
        card(content, "✦  SHADER & TEXTURE PACKS", "Bedrock shader support depends on your Minecraft version and device. Many older shader packs do not work with newer RenderDragon versions.", "IMPORT VISUAL PACK") { pickPack() }
        card(content, "CURSEFORGE", "Browse Bedrock add-ons in the built-in browser. Check each download's game-version compatibility.", "BROWSE CURSEFORGE") { startActivity(Intent(this, BrowserActivity::class.java)) }
        card(content, "ABOUT", "Unofficial companion launcher. Not affiliated with Mojang, Microsoft, Minecraft or CurseForge. No add-ons are bundled; choose trusted files and review permissions.") 

        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val footer = LinearLayout(this).apply { gravity = Gravity.CENTER }
        footer.addView(text("HOME     •     MODS     •     SETTINGS", 11f, green, true))
        root.addView(footer)
        setContentView(root)
    }

    private fun showPerformance() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 20, 20, 20)
            setBackgroundColor(dark)
        }
        root.addView(text("FPS PERFORMANCE GUIDE", 23f, cream, true))
        root.addView(text("These are safe in-game suggestions, not a guaranteed FPS increase.", 14f, green))
        listOf(
            "Render distance: start at 6–8 chunks",
            "Fancy graphics: OFF",
            "Beautiful skies: OFF if performance is low",
            "Particles: DECREASED",
            "Smooth lighting: OFF or lower",
            "Close unused apps and keep Android updated",
            "Avoid overheating; remove heavy background downloads"
        ).forEach { root.addView(text("•  $it", 16f)) }
        root.addView(button("BACK", { showHome() }))
        setContentView(root)
    }

    private fun pickPack() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf(
                "application/octet-stream",
                "application/zip",
                "application/x-minecraft-pack"
            ))
        }
        try { startActivityForResult(intent, 41) }
        catch (_: ActivityNotFoundException) { Toast.makeText(this, "No file picker found.", Toast.LENGTH_LONG).show() }
    }

    @Deprecated("Deprecated in Android")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 41 && resultCode == RESULT_OK) {
            val uri: Uri = data?.data ?: return
            val open = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, "*/*")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            try {
                startActivity(Intent.createChooser(open, "Open pack with"))
            } catch (_: ActivityNotFoundException) {
                Toast.makeText(this, "No app can open this pack. Try opening it from your Files app with Minecraft installed.", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun launchMinecraft() {
        val launch = packageManager.getLaunchIntentForPackage("com.mojang.minecraftpe")
        if (launch != null) startActivity(launch)
        else Toast.makeText(this, "Minecraft Bedrock was not found. Install it from Google Play first.", Toast.LENGTH_LONG).show()
    }
}
